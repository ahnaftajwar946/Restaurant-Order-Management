package Order.guistuff;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import javax.swing.border.Border;
import java.text.DecimalFormat;


public class Home {
    JMenu menu;
    JMenu orders;
    JMenuItem home, info, invest, lunch, dinner;
    double investment;

    //These are local variables that can be used for the payment's
    ArrayList<String> invoice = new ArrayList<>();
    String customerName  = JOptionPane.showInputDialog(null, "Name: ");
    Order.Menu customer = new Order.Menu(customerName);
    double orderTotal; //Total from the lunch and dinner menu
    double investmentTotal; //Total from the investment selection



    public Home() {
        investment = 0;
        JFrame frame = new JFrame("Home");
        JMenuBar menuBar = new JMenuBar();
        menu = new JMenu("Main Menu");
        menuBar.add(menu);

        JLabel label = new JLabel("Home", SwingConstants.CENTER);
        label.setFont(new Font("Serif", Font.BOLD, 24));
        label.setForeground(Color.RED);
        label.setBackground(Color.ORANGE);
        label.setOpaque(true);


        label.setText("Welcome to Blaze Kitchen!");

        orders = new JMenu("Kitchen Menu");
        invest = new JMenuItem("Investment Opportunities");
        info = new JMenuItem("About us");
        home = new JMenuItem("Home");


        menu.add(home);
        menu.add(orders);
        menu.add(invest);
        menu.add(info);

        lunch = new JMenuItem("Lunch");
        dinner = new JMenuItem("Dinner");

        lunch.addActionListener(event -> onCreateLunchClick(customerName));
        dinner.addActionListener(event -> onCreateDinnerClick(customerName));

        orders.add(lunch);
        orders.add(dinner);


        frame.setJMenuBar(menuBar);
        frame.add(label);
        frame.setSize(512, 512);
        frame.setLocationRelativeTo(null);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);


        JPanel panel = new JPanel();
        panel.setBackground(Color.RED);

        JButton blunch = new JButton("Lunch Order");
        blunch.setBounds(70, 80, 150, 90);
        blunch.setBackground(Color.DARK_GRAY);
        blunch.setForeground(Color.WHITE);
        Border border = BorderFactory.createLineBorder(Color.BLACK);
        blunch.setBorder(border);
        blunch.setActionCommand("Create lunch order");
        blunch.setToolTipText("Create a new lunch order");
        panel.add(blunch);
        blunch.addActionListener(event -> onCreateLunchClick(customerName));

        JButton bdinner = new JButton("Dinner Order");
        bdinner.setBounds(70, 80, 150, 90);
        bdinner.setBackground(Color.DARK_GRAY);
        bdinner.setForeground(Color.WHITE);
        bdinner.setBorder(border);
        bdinner.setActionCommand("Create dinner order");
        bdinner.setToolTipText("Create a new dinner order");
        panel.add(bdinner);
        bdinner.addActionListener(event -> onCreateDinnerClick(customerName));

        JButton bpaymentOptions = new JButton("Payment Options");
        bpaymentOptions.setBounds(70, 80, 150, 90);
        bpaymentOptions.setBackground(Color.DARK_GRAY);
        bpaymentOptions.setForeground(Color.WHITE);
        bpaymentOptions.setBorder(border);
        bpaymentOptions.setActionCommand("Payment Method");
        bpaymentOptions.setToolTipText("Select payment method");
        panel.add(bpaymentOptions);
        bpaymentOptions.addActionListener(event -> onChoosePaymentClick());

        frame.getContentPane().add(BorderLayout.NORTH, panel);
        frame.setVisible(true);

        info.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                label.setFont(new Font("Serif", Font.BOLD, 24));
                label.setText("<html>" + "The restaurant was founded in Arlington, Texas by Ahnaf Tajwar Kamal, Gwendolyn Beecher, Tanjimul Arnab, Kamryn Jimenez, and Akshay Rupakula. It was founded with the goal to provide quality food made with quality ingredients at a competitive price. Over time we are looking to expand our business to other cities across Texas and eventually to other states. We hope you enjoy your time here and we look forward to serving you and your family!" + "</html>");
            }
        });

        home.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                label.setFont(new Font("Serif", Font.BOLD, 24));
                label.setText("Welcome to Blaze Kitchen!");
            }
        });

        invest.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                String getNum = JOptionPane.showInputDialog(null, "How much would you like to invest within the company? ");
                investmentTotal += Double.parseDouble(getNum);

                JOptionPane.showMessageDialog(frame, "Currently you have $" + investmentTotal + " invested within the company. We appreciate your patronage.");
            }
        });


    }


    protected void onCreateLunchClick(String customerName) {

        JFrame frame = new JFrame("Lunch");

        ArrayList<String> items;
        items = Order.Menu.getDinner();

        JComboBox comboBox = new JComboBox();
        comboBox.setModel(new DefaultComboBoxModel<>(Order.Menu.getLunch().toArray(new String[items.size()])));


        JPanel panel = new JPanel();
        panel.setBackground(Color.RED);
        panel.add(comboBox);

        frame.add(panel);
        frame.setSize(400, 100);
        frame.setLocationRelativeTo(null);

        comboBox.setVisible(true);
        frame.setVisible(true);


        Border border = BorderFactory.createLineBorder(Color.BLACK);

        JButton buttonb1 = new JButton("Add to Order");
        buttonb1.setBackground(Color.DARK_GRAY);
        buttonb1.setForeground(Color.WHITE);
        buttonb1.setBounds(70, 80, 150, 90);
        buttonb1.setBorder(border);
        panel.add(buttonb1);

        JButton buttonb2 = new JButton("Current Cart");
        buttonb2.setBackground(Color.DARK_GRAY);
        buttonb2.setForeground(Color.WHITE);
        buttonb2.setBounds(70, 80, 150, 90);
        buttonb2.setBorder(border);
        panel.add(buttonb2);


        buttonb1.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                customer.addLunchOrder((String) comboBox.getSelectedItem());

            }
        });
        buttonb2.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                ArrayList<String> lunchCart = new ArrayList<>();
                ArrayList<String> dinnerCart = new ArrayList<>();


                lunchCart = customer.getLunchInvoice();
                dinnerCart = customer.getDinnerInvoice();

                String lunchList = "";
                String dinnerList = "";

                for(int i = 0; i < lunchCart.size(); i++){
                    String b = lunchCart.get(i);
                    lunchList += b + "\n";
                }

                for(int i = 0; i < dinnerCart.size(); i++){
                    String a = dinnerCart.get(i);

                    dinnerList += a + "\n";

                }

                DecimalFormat df = new DecimalFormat("#.##");
                JOptionPane.showMessageDialog(null, "Current cart: \n Lunch: \n" + lunchList + "\nLunch Total: $" + df.format(customer.getLunchTotal())+ "\n\nDinner: \n" + dinnerList + "\nDinner Total: $" + df.format(customer.getDinnerTotal()) + "\n\n\nInvoice total:\n $" + df.format(customer.addTotal()));


            }

        });
        orderTotal = customer.addTotal();

    }

    protected void onCreateDinnerClick(String customerName) {

        JFrame frame = new JFrame("Dinner");

        ArrayList<String> items;
        items = Order.Menu.getDinner();

        JComboBox comboBox = new JComboBox();
        comboBox.setModel(new DefaultComboBoxModel<>(Order.Menu.getDinner().toArray(new String[items.size()])));


        JPanel panel = new JPanel();
        panel.setBackground(Color.RED);
        panel.add(comboBox);

        frame.add(panel);
        frame.setSize(400, 100);
        frame.setLocationRelativeTo(null);

        comboBox.setVisible(true);
        frame.setVisible(true);


        Border border = BorderFactory.createLineBorder(Color.BLACK);

        JButton buttonb1 = new JButton("Add to Order");
        buttonb1.setBackground(Color.DARK_GRAY);
        buttonb1.setForeground(Color.WHITE);
        buttonb1.setBounds(70, 80, 150, 90);
        buttonb1.setBorder(border);
        panel.add(buttonb1);

        JButton buttonb2 = new JButton("Current Cart");
        buttonb2.setBackground(Color.DARK_GRAY);
        buttonb2.setForeground(Color.WHITE);
        buttonb2.setBounds(70, 80, 150, 90);
        buttonb2.setBorder(border);
        panel.add(buttonb2);


        buttonb1.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {

                customer.addDinnerOrder((String) comboBox.getSelectedItem());
            }
        });

        buttonb2.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {

                ArrayList<String> lunchCart = new ArrayList<>();
                ArrayList<String> dinnerCart = new ArrayList<>();


                lunchCart = customer.getLunchInvoice();
                dinnerCart = customer.getDinnerInvoice();

                String lunchList = "";
                String dinnerList = "";

                for(int i = 0; i < lunchCart.size(); i++){
                    String b = lunchCart.get(i);
                    lunchList += b + "\n";
                }

                for(int i = 0; i < dinnerCart.size(); i++){
                    String a = dinnerCart.get(i);

                    dinnerList += a + "\n";

                }

                DecimalFormat df = new DecimalFormat("#.##");
                JOptionPane.showMessageDialog(null, "Current cart: \n Lunch: " + lunchList + "\nLunch Total: $" + df.format(customer.getLunchTotal())+ "\n\nDinner: " + dinnerList + "\nDinner Toal: $" + df.format(customer.getDinnerTotal()) + "\n\n\nInvoice total:\n $" + df.format(customer.addTotal()));


            }

        });
        orderTotal = customer.addTotal();
    }
    protected void onChoosePaymentClick(){
        JFrame frame = new JFrame("Payments");

        JPanel panel = new JPanel();
        panel.setBackground(Color.RED);

        frame.add(panel);
        frame.setSize(400, 100);
        frame.setLocationRelativeTo(null);
        frame.setVisible(true);


        Border border = BorderFactory.createLineBorder(Color.BLACK);

        JButton card = new JButton("Card");
        card.setBackground(Color.DARK_GRAY);
        card.setForeground(Color.WHITE);
        card.setBounds(70, 80, 150, 90);
        card.setBorder(border);
        panel.add(card);

        JButton cash = new JButton("Cash");
        cash.setBackground(Color.DARK_GRAY);
        cash.setForeground(Color.WHITE);
        cash.setBounds(70, 80, 150, 90);
        cash.setBorder(border);
        panel.add(cash);


        card.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                    int answer = JOptionPane.showConfirmDialog(null, "Are you sure you want pay by card?");

                    switch (answer) {
                        case JOptionPane.YES_OPTION:
                            JTextField issuer = new JTextField();
                            JTextField cardNum = new JTextField();
                            JPasswordField pin = new JPasswordField();
                            int counter = 0; //serves as a check that all fields have been filled. When counter==3 all fields are filled
                            String info = "Enter your card issuer, card number, and PIN:";
                            answer = JOptionPane.showOptionDialog(frame, new Object[] {info, issuer,cardNum, pin},
                                    "Card Information", JOptionPane.OK_CANCEL_OPTION, JOptionPane.QUESTION_MESSAGE, null, null, null);
                            if (answer == JOptionPane.OK_OPTION&&issuer.getText().isEmpty()){
                                JOptionPane.showMessageDialog(frame, "Enter your credit card issuer.");
                            }
                            else{
                                counter++;
                            }
                            if (answer == JOptionPane.OK_OPTION&&cardNum.getText().isEmpty()){
                                JOptionPane.showMessageDialog(frame, "Enter your card number.");
                            }
                            else{
                                counter++;
                            }
                            if (answer == JOptionPane.OK_OPTION&&pin.getText().isEmpty()){
                                JOptionPane.showMessageDialog(frame, "Enter your PIN.");
                            }
                            else if(pin.getText().length()==4){
                                counter++;
                            }
                            else{
                                JOptionPane.showMessageDialog(frame, "PIN must be four digits.");
                            }
                            if (counter==3){
                                JOptionPane.showMessageDialog(frame, "Accepted. Thank you for your business and have a great day!");
                            }
                            else {
                                JOptionPane.showMessageDialog(frame, "Card not accepted. Please try again.");
                            }
                            break;

                        case JOptionPane.NO_OPTION:
                            break;

                        case JOptionPane.CANCEL_OPTION:
                            JOptionPane.showMessageDialog(frame, "Canceled.");
                            break;

                    }
                }
            });


        cash.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {

                int answer = JOptionPane.showConfirmDialog(null, "Are you sure you want pay by cash?");

                switch (answer) {
                    case JOptionPane.YES_OPTION:
                        JTextField numCash = new JTextField();
                        String info = "How much cash would you like to pay?:";
                        answer = JOptionPane.showOptionDialog(frame, new Object[] {info, numCash},
                                "Cash Payment", JOptionPane.OK_CANCEL_OPTION, JOptionPane.QUESTION_MESSAGE, null, null, null);
                        if (answer == JOptionPane.OK_OPTION&&numCash.getText().isEmpty()){
                            JOptionPane.showMessageDialog(frame, "Enter the amount of cash you would like to pay.");
                        }

                        break;
                    case JOptionPane.NO_OPTION:
                        break;

                    case JOptionPane.CANCEL_OPTION:
                        JOptionPane.showMessageDialog(frame, "Canceled.");
                        break;
                }
            }

        });
    }

}




