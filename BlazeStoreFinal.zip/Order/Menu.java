package Order;


import java.util.ArrayList;
import java.util.List;

public class Menu extends CustObject {

    public static ArrayList<String> dinner = new ArrayList<>();
    public static ArrayList<String> lunch = new ArrayList<>();

    String name;

    public Menu(String name) {
        super(name);

    }


    public static ArrayList<String> getLunch(){
        lunch.add("Mediterranean Salad, 12.99");
        lunch.add("Pita and Hummus, 8.99");
        lunch.add("Gyro Sandwich 11.99");
        lunch.add("Greek Beef pitas, 13.49");
        lunch.add("Greek garlic chicken, 15.49");
        lunch.add("Chicken Orzo Soup, 9.99");
        lunch.add("Greek Couscous Salad, 7.99");
        return lunch;

    }

    public static ArrayList<String> getDinner(){
        dinner.add("Caprese Stuffed Portobello Mushrooms, 16.99");
        dinner.add("White Bean & veggie Salad, 14.49");
        dinner.add("Eggpland Pomodoro pasta, 24.99");
        dinner.add("Grilled Pork loin with white bean puree, 26.99");
        dinner.add("Gnocchi with Zucchini Ribbons, 26.99");
        dinner.add("Tortellini Salad, 13.99");
        dinner.add("Bean Bolognese, 17.99");
         return dinner;
    }
    public ArrayList<String> addLunchOrder(String order){
        lunchInvoice.add(order);
        String [] splitInvoice = order.split(",");
        double d = 0;

        for(int i = 0; i < splitInvoice.length; i = i+2){
            d = Double.parseDouble(splitInvoice[i+1]);
            double tempTotal = d + d;
            lunchTotal = lunchTotal + d;
        }

        return lunchInvoice;
    }
    public ArrayList<String> addDinnerOrder(String order){
        dinnerInvoice.add(order);
        String [] splitInvoice = order.split(",");
        double d = 0;

            for(int i = 0; i < splitInvoice.length; i = i+2){
            d = Double.parseDouble(splitInvoice[i+1]);
            double tempTotal = d + d;
            dinnerTotal = dinnerTotal + d;
        }
        return dinnerInvoice;
    }


    public double addTotal(){
        total = lunchTotal + dinnerTotal;
        return total;
    }

}
