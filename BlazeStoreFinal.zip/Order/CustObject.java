package Order;

import java.util.ArrayList;

public class CustObject {

    String name;
    Double total = 0.0;
    Double lunchTotal = 0.0;
    Double dinnerTotal = 0.0;

    public ArrayList<String> lunchInvoice = new ArrayList<>();
    public ArrayList<String> dinnerInvoice = new ArrayList<>();
    public ArrayList<String> invoiceTotal = new ArrayList<>();

    public CustObject(String name){
        this.name = name;
    }

    public String getName(){
        return name;
    }

    public double getLunchTotal(){
        return lunchTotal;
    }
    public double getDinnerTotal(){
        return dinnerTotal;
    }

    public ArrayList<String> getLunchInvoice(){
        return lunchInvoice;
    }
    public ArrayList<String> getDinnerInvoice(){
        return dinnerInvoice;
    }
    public ArrayList<String> getTotalInvoice(){
        return invoiceTotal;
    }

    public ArrayList<String> addLunchInvoice(String order){
    lunchInvoice.add(order);
    return lunchInvoice;
    }

    public ArrayList<String> addDinnerInvoice(String order){
        dinnerInvoice.add(order);
        return dinnerInvoice;
    }
    public ArrayList<String> addToTotalInvoice(String order){
     invoiceTotal.add(order);
     return invoiceTotal;
    }




}
